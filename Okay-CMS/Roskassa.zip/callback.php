<?php

// Работаем в корневой директории
chdir ('../../');
require_once('api/Okay.php');
$okay = new Okay();

// Выбираем из ответа нужные данные
$amount				= $okay->request->post('amount');
$currency			= $okay->request->post('currency');
$roskassa_order_id	= $okay->request->post('order_id');
$order_id			= intval(substr($roskassa_order_id, 0, strpos($roskassa_order_id, '-')));
$signature			= $okay->request->post('sign');
$status				= $okay->request->post('status');

if($status !== "1")
	die("bad status");

////////////////////////////////////////////////
// Выберем заказ из базы
////////////////////////////////////////////////
$order = $okay->orders->get_order(intval($order_id));
if(empty($order))
	die('Оплачиваемый заказ не найден');
 
////////////////////////////////////////////////
// Выбираем из базы соответствующий метод оплаты
////////////////////////////////////////////////
$method = $okay->payment->get_payment_method(intval($order->payment_method_id));
if(empty($method))
	die("Неизвестный метод оплаты");
	
$settings = unserialize($method->settings);
$payment_currency = $okay->money->get_currency(intval($method->currency_id));

// Валюта должна совпадать
if ($currency == "RUB")
	$currency = "RUR";
if($currency !== $payment_currency->code)
	die("bad currency");

// Проверяем контрольную подпись
$arrSign = $_POST;
unset($arrSign['sign']);
ksort($arrSign); // сортируем по ключам в алфавитном порядке элементы массива 
$signString = http_build_query($arrSign); // Генеририруем URL-кодированную строку запроса
$mysignature = md5($signString . $settings['roskassa_private_key']); // берем MD5 хэш в бинарном виде по сформированной строке

if($mysignature !== $signature)
	die("bad sign".$signature);

// Нельзя оплатить уже оплаченный заказ  
if($order->paid)
	die('order already paid');

if($amount != round($okay->money->convert($order->total_price, $method->currency_id, false), 2) || $amount<=0)
	die("incorrect price");
	       
// Установим статус оплачен
$okay->orders->update_order(intval($order->id), array('paid'=>1));

// Отправим уведомление на email
$okay->notify->email_order_user(intval($order->id));
$okay->notify->email_order_admin(intval($order->id));

// Спишем товары  
$okay->orders->close(intval($order->id));

// Перенаправим пользователя на страницу заказа
// header('Location: '.$okay->config->root_url.'/order/'.$order->url);

exit();