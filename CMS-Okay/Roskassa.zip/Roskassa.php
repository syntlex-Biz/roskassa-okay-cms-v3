<?php

/*

Plugin Name: Payment Gateway for Integration of RosKassa with OkeyCMS 2

Plugin URI: https://Syntlex.Biz/

Description: Payment Gateway for Integration of RosKassa with OkeyCMS 2 - the best Payment Processing 

Version: 1.1

Author: Syntlex Biz

Author URI: https://syntlex.biz 

Copyright: © 2021 Syntlex Biz.

License: GNU General Public License v3.0

License URI: http://www.gnu.org/licenses/gpl-3.0.html

 */

require_once('api/Okay.php');

class Roskassa extends Okay
{	
	public function checkout_form($order_id)
	{
		
		$order = $this->orders->get_order((int)$order_id);
		$order_id = $order->id."-".rand(100000, 999999);
		$payment_method = $this->payment->get_payment_method($order->payment_method_id);
		$payment_currency = $this->money->get_currency(intval($payment_method->currency_id));
		$settings = $this->payment->get_payment_settings($payment_method->id);
		
		$currency = ($payment_currency->code == "RUR") ? "RUB" : $payment_currency->code;
		$price = round($this->money->convert($order->total_price, $payment_method->currency_id, false), 2);	

		$private_key = $settings['roskassa_private_key'];
		$public_key = $settings['roskassa_public_key'];

        $res['shop_id'] = $public_key;
        $res['amount'] = $price;
        $res['currency'] = $currency;
        $res['order_id'] = $order_id;
        $res['test'] = 1; // 1 - включить, 0 - выключить
        $res['sign'] = $this->get_sign($res, $private_key);

		return $res;
	}

	public function get_sign($data, $key)
	{
		ksort($data);
		$string = http_build_query($data);
		$sign = md5($string . $key);
		return $sign;
	}
}